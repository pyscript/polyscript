from js import document

document.body.append("a")
